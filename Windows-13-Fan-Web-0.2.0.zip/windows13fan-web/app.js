const state = {
  z: 100,
  windows: new Map(),
  installed: JSON.parse(localStorage.getItem('w13-installed') || JSON.stringify(['calculator','notes','terminal','explorer','browser','settings','store'])),
  wallpaper: localStorage.getItem('w13-wallpaper') || '',
  accent: localStorage.getItem('w13-accent') || '#4f8cff',
  theme: localStorage.getItem('w13-theme') || 'dark'
};

document.documentElement.style.setProperty('--accent', state.accent);
if (state.wallpaper) document.getElementById('desktop').style.backgroundImage = `url(${state.wallpaper})`;

const apps = {
  explorer: { name:'Explorador de archivos', desc:'Navega por tus carpetas', icon:'EX' },
  browser: { name:'Navegador', desc:'Abre sitios web', icon:'WB' },
  store: { name:'Windows 13 Fan Store', desc:'Instala y administra apps', icon:'ST' },
  settings: { name:'Configuración', desc:'Personaliza el sistema', icon:'CF' },
  calculator: { name:'Calculadora', desc:'Operaciones matemáticas', icon:'CL' },
  notes: { name:'Notas', desc:'Editor de texto local', icon:'NT' },
  terminal: { name:'Terminal', desc:'Terminal de comandos', icon:'TR' },
  task: { name:'Administrador de tareas', desc:'Rendimiento del sistema', icon:'TM' }
};

function persist() { localStorage.setItem('w13-installed', JSON.stringify(state.installed)); }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function renderStart(filter='') {
  const box = document.getElementById('start-apps');
  const q = filter.toLowerCase();
  const list = state.installed.map(id => ({id, ...apps[id]})).filter(a => a.name.toLowerCase().includes(q));
  box.innerHTML = list.length ? list.map(a => `<button class="app-row" data-open="${a.id}"><span class="mini-icon">${a.icon}</span><span><b>${esc(a.name)}</b><small>${esc(a.desc)}</small></span></button>`).join('') : '<div class="status">No se encontraron aplicaciones.</div>';
  box.querySelectorAll('[data-open]').forEach(b => b.onclick = () => { openApp(b.dataset.open); closeStart(); });
}

function closeStart(){ document.getElementById('start-menu').classList.add('hidden'); document.getElementById('start-button').classList.remove('active'); }
function toggleStart(){ const el=document.getElementById('start-menu'); el.classList.toggle('hidden'); document.getElementById('start-button').classList.toggle('active', !el.classList.contains('hidden')); if(!el.classList.contains('hidden')) { renderStart(); document.getElementById('app-search').focus(); } }

document.getElementById('start-button').onclick = toggleStart;
document.getElementById('close-start').onclick = closeStart;
document.getElementById('app-search').oninput = e => renderStart(e.target.value);

document.querySelectorAll('[data-app]').forEach(el => el.addEventListener('click', () => {
  const id=el.dataset.app;
  if (id==='search') { toggleStart(); document.getElementById('app-search').focus(); return; }
  openApp(id);
}));

document.querySelectorAll('[data-action="settings"]').forEach(b=>b.onclick=()=>{closeStart();openApp('settings')});
document.querySelector('[data-action="power"]').onclick=()=> alert('Modo de apagado de demostración. En la versión nativa se conectará al sistema operativo.');

document.getElementById('desktop').addEventListener('contextmenu', e=>{
  if(e.target.closest('.window') || e.target.closest('.taskbar') || e.target.closest('#start-menu')) return;
  e.preventDefault(); const m=document.getElementById('context-menu'); m.style.left=Math.min(e.clientX, innerWidth-200)+'px'; m.style.top=Math.min(e.clientY, innerHeight-250)+'px'; m.classList.remove('hidden');
});
document.addEventListener('click', e=>{ if(!e.target.closest('#context-menu')) document.getElementById('context-menu').classList.add('hidden'); });
document.querySelector('[data-action="refresh"]').onclick=()=>location.reload();
document.querySelector('[data-action="personalize"]').onclick=()=>openApp('settings');
document.querySelector('#context-menu [data-action="settings"]').onclick=()=>openApp('settings');

function openApp(id) {
  if (!apps[id]) return;
  if (state.windows.has(id)) { const w=state.windows.get(id); w.classList.remove('minimized'); focusWindow(w); return; }
  const w=document.createElement('section'); w.className='window focused'; w.dataset.app=id; w.style.left=(90 + (state.windows.size*24)%260)+'px'; w.style.top=(65 + (state.windows.size*22)%170)+'px'; w.style.zIndex=++state.z;
  w.innerHTML=`<div class="titlebar"><div class="titlebar-title">${esc(apps[id].name)}</div><div class="window-controls"><button data-win="min">−</button><button data-win="max">□</button><button class="close" data-win="close">×</button></div></div><div class="window-content">${contentFor(id)}</div>`;
  document.getElementById('windows').appendChild(w); state.windows.set(id,w); wireWindow(w,id); updateTaskbar(); focusWindow(w);
}

function contentFor(id) {
  if(id==='explorer') return explorerContent();
  if(id==='browser') return browserContent();
  if(id==='store') return storeContent();
  if(id==='settings') return settingsContent();
  if(id==='calculator') return calculatorContent();
  if(id==='notes') return `<div class="toolbar"><button class="ui-button primary" id="save-note">Guardar</button><span class="status" id="note-status"></span></div><textarea id="notes-area" class="notes" placeholder="Escribe aquí..."></textarea>`;
  if(id==='terminal') return terminalContent();
  if(id==='task') return taskContent();
}

function explorerContent(){ return `<div class="toolbar"><button class="ui-button" id="new-folder">Nueva carpeta</button><button class="ui-button" id="new-file">Nuevo archivo</button><button class="ui-button" id="explorer-refresh">Actualizar</button></div><div class="status" style="margin-bottom:10px">Este explorador usa el almacenamiento del navegador en la versión web.</div><div class="explorer-list" id="file-list"></div>`; }
function renderVirtualFiles(){
  const files=JSON.parse(localStorage.getItem('w13-files')||JSON.stringify([{name:'Documentos',type:'folder'},{name:'Descargas',type:'folder'},{name:'Imágenes',type:'folder'},{name:'notas.txt',type:'file'}]));
  const list=document.querySelector('.window[data-app="explorer"] #file-list'); if(!list)return;
  list.innerHTML=files.map((f,i)=>`<div class="file-item"><span>${f.type==='folder'?'DIR':'FILE'}</span><span style="flex:1">${esc(f.name)}</span><button class="plain-button" data-delete="${i}" title="Eliminar">×</button></div>`).join('');
  list.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>{files.splice(+b.dataset.delete,1);localStorage.setItem('w13-files',JSON.stringify(files));renderVirtualFiles()});
}

function browserContent(){ return `<div class="browser-bar"><button class="ui-button" id="back">←</button><button class="ui-button" id="forward">→</button><input id="url" value="https://www.youtube.com"/><button class="ui-button primary" id="go">Ir</button></div><iframe class="browser-frame" id="browser-frame" title="Navegador web" src="https://www.youtube.com/embed?rel=0"></iframe><p class="status">Algunos sitios bloquean la carga dentro de iframes. El navegador nativo de Windows 13 Fan podrá abrirlos directamente en una WebView.</p>`; }
function navigateBrowser(){ let v=document.querySelector('.window[data-app="browser"] #url').value.trim(); if(!v)return; if(!/^https?:\/\//i.test(v)) v='https://www.google.com/search?q='+encodeURIComponent(v); document.querySelector('.window[data-app="browser"] #browser-frame').src=v; }

function storeContent(){
  const catalog=[
    {id:'calculator',name:'Calculadora',desc:'Calculadora integrada'},
    {id:'notes',name:'Notas',desc:'Editor de texto'},
    {id:'terminal',name:'Terminal',desc:'Línea de comandos'},
    {id:'task',name:'Administrador de tareas',desc:'Monitor del sistema'},
    {id:'browser',name:'Navegador',desc:'Navegación web'},
    {id:'explorer',name:'Explorador',desc:'Archivos y carpetas'},
    {id:'settings',name:'Configuración',desc:'Opciones del sistema'}
  ];
  return `<div class="toolbar"><input class="search-input" id="store-search" placeholder="Buscar en Store..." style="margin:0"><span class="status" id="store-count"></span></div><div class="store-grid" id="store-grid">${catalog.map(a=>storeCard(a)).join('')}</div>`;
}
function storeCard(a){ const installed=state.installed.includes(a.id); return `<div class="store-card"><h3>${esc(a.name)}</h3><p>${esc(a.desc)}</p><button class="ui-button ${installed?'':'primary'}" data-store="${a.id}" data-mode="${installed?'open':'install'}">${installed?'Abrir':'Instalar'}</button>${installed?` <button class="ui-button" data-uninstall="${a.id}">Desinstalar</button>`:''}</div>`; }
function refreshStore(){ const w=document.querySelector('.window[data-app="store"]'); if(!w)return; w.querySelector('#store-grid').innerHTML=['calculator','notes','terminal','task','browser','explorer','settings'].map(id=>({id,...apps[id]})).map(a=>storeCard(a)).join(''); wireStore(w); }
function wireStore(w){ w.querySelectorAll('[data-store]').forEach(b=>b.onclick=()=>{const id=b.dataset.store;if(b.dataset.mode==='install'){if(!state.installed.includes(id))state.installed.push(id);persist();refreshStore();renderStart();}else openApp(id)}); w.querySelectorAll('[data-uninstall]').forEach(b=>b.onclick=()=>{const id=b.dataset.uninstall;if(id==='store')return;if(!confirm('¿Desinstalar '+apps[id].name+'?'))return;state.installed=state.installed.filter(x=>x!==id);persist();if(state.windows.has(id))closeWindow(state.windows.get(id));refreshStore();renderStart()}); const s=w.querySelector('#store-search'); if(s)s.oninput=()=>{const q=s.value.toLowerCase();w.querySelectorAll('.store-card').forEach(c=>c.style.display=c.innerText.toLowerCase().includes(q)?'':'none')}; }

function settingsContent(){ return `<div class="settings-grid"><nav class="settings-nav"><button class="active" data-settings="personal">Personalización</button><button data-settings="display">Pantalla</button><button data-settings="performance">Rendimiento</button><button data-settings="system">Sistema</button></nav><div id="settings-page"></div></div>`; }
function renderSettings(w, page='personal'){
  const p=w.querySelector('#settings-page');
  if(page==='personal') p.innerHTML=`<h2>Personalización</h2><div class="setting-row"><span>Tema</span><select id="theme"><option value="dark">Oscuro</option><option value="light">Claro</option></select></div><div class="setting-row"><span>Color de acento</span><input id="accent" type="color" value="${state.accent}"></div><div class="setting-row"><span>Desenfoque del escritorio</span><input id="blur" type="range" min="0" max="35" value="18"></div><div class="setting-row"><span>Fondo personalizado</span><input id="wallpaper" type="file" accept="image/*"></div>`;
  if(page==='display') p.innerHTML=`<h2>Pantalla</h2><div class="setting-row"><span>Escala de interfaz</span><select><option>100%</option><option>110%</option><option>125%</option><option>150%</option></select></div><div class="setting-row"><span>Animaciones</span><input type="checkbox" checked></div><div class="setting-row"><span>Frecuencia de actualización</span><select><option>Automática</option><option>60 Hz</option><option>120 Hz</option><option>144 Hz</option></select></div>`;
  if(page==='performance') p.innerHTML=`<h2>Rendimiento</h2><div class="grid"><div class="card"><b>Memoria</b><div id="ram-info" class="status">Consultando...</div></div><div class="card"><b>CPU</b><div class="status">${navigator.hardwareConcurrency||'N/D'} hilos lógicos detectados</div></div><div class="card"><b>GPU</b><div id="gpu-info" class="status">Consultando WebGL...</div></div><div class="card"><b>WebGPU</b><div id="webgpu-info" class="status">Consultando...</div></div></div>`;
  if(page==='system') p.innerHTML=`<h2>Sistema</h2><div class="setting-row"><span>Plataforma</span><span class="status">${esc(navigator.platform)}</span></div><div class="setting-row"><span>Navegador</span><span class="status">${esc(navigator.userAgent.split(')')[0]+')')}</span></div><div class="setting-row"><span>Idioma</span><span class="status">${esc(navigator.language)}</span></div>`;
  const t=w.querySelector('#theme'); if(t){t.value=state.theme;t.onchange=()=>setTheme(t.value)}
  const a=w.querySelector('#accent'); if(a)a.oninput=()=>{state.accent=a.value;localStorage.setItem('w13-accent',a.value);document.documentElement.style.setProperty('--accent',a.value)};
  const bl=w.querySelector('#blur'); if(bl)bl.oninput=()=>document.getElementById('desktop').style.setProperty('--dummy',bl.value+'px');
  const file=w.querySelector('#wallpaper'); if(file)file.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{state.wallpaper=r.result;localStorage.setItem('w13-wallpaper',r.result);document.getElementById('desktop').style.backgroundImage=`url(${r.result})`};r.readAsDataURL(f)};
  if(page==='performance') updatePerformance(w);
}
function setTheme(t){state.theme=t;localStorage.setItem('w13-theme',t);document.body.dataset.theme=t;document.documentElement.style.setProperty('--panel',t==='light'?'rgba(245,247,252,.86)':'rgba(17,22,32,.86)');document.documentElement.style.setProperty('--text',t==='light'?'#172033':'#f4f7ff');document.documentElement.style.setProperty('--muted',t==='light'?'#5f6878':'#aeb9cc');}
async function updatePerformance(w){ const ram=w.querySelector('#ram-info'); if(navigator.deviceMemory)ram.textContent=navigator.deviceMemory+' GB aproximados expuestos por el navegador';else ram.textContent='No disponible en este navegador'; const c=document.createElement('canvas');const gl=c.getContext('webgl')||c.getContext('experimental-webgl');w.querySelector('#gpu-info').textContent=gl?(gl.getParameter(gl.RENDERER)||'GPU detectada'):'WebGL no disponible'; w.querySelector('#webgpu-info').textContent=navigator.gpu?'Disponible':'No disponible'; }

function calculatorContent(){ return `<div class="calc"><input id="calc-display" class="calc-display" value="0" readonly><div class="calc-grid">${['C','⌫','%','/','7','8','9','*','4','5','6','-','1','2','3','+','0','.','(',')','=',''].map((x,i)=>`<button data-calc="${x}">${x}</button>`).join('')}</div></div>`; }
function terminalContent(){ return `<div class="terminal" id="terminal-box"><div>Windows 13 Fan Terminal</div><div class="status">Escribe "help" para ver comandos.</div><br><div id="terminal-output"></div><div style="display:flex"><span>W13&gt;&nbsp;</span><input id="terminal-input" class="terminal-input" autocomplete="off"></div></div>`; }
function taskContent(){ return `<div class="toolbar"><button class="ui-button" id="task-refresh">Actualizar</button></div><div class="grid"><div class="card"><b>Hilos lógicos</b><h2>${navigator.hardwareConcurrency||'N/D'}</h2></div><div class="card"><b>Memoria expuesta</b><h2>${navigator.deviceMemory?navigator.deviceMemory+' GB':'N/D'}</h2></div><div class="card"><b>WebGPU</b><h2>${navigator.gpu?'Sí':'No'}</h2></div><div class="card"><b>WebGL</b><h2>${(()=>{const c=document.createElement('canvas');return c.getContext('webgl')?'Sí':'No'})()}</h2></div></div><p class="status">Los navegadores limitan el acceso directo a métricas como temperatura, uso real de CPU y uso real de GPU. La versión Tauri podrá consultar más datos del sistema con permisos nativos.</p>`; }

function wireWindow(w,id){
  w.addEventListener('mousedown',()=>focusWindow(w));
  w.querySelector('[data-win="close"]').onclick=()=>closeWindow(w);
  w.querySelector('[data-win="min"]').onclick=()=>{w.classList.add('minimized');updateTaskbar()};
  w.querySelector('[data-win="max"]').onclick=()=>{w.classList.toggle('maximized');focusWindow(w)};
  makeDraggable(w);
  if(id==='explorer'){renderVirtualFiles();w.querySelector('#new-folder').onclick=()=>addVirtualFile('Nueva carpeta','folder');w.querySelector('#new-file').onclick=()=>addVirtualFile('Nuevo archivo.txt','file');w.querySelector('#explorer-refresh').onclick=renderVirtualFiles;}
  if(id==='browser'){w.querySelector('#go').onclick=navigateBrowser;w.querySelector('#url').addEventListener('keydown',e=>{if(e.key==='Enter')navigateBrowser()});w.querySelector('#back').onclick=()=>w.querySelector('#browser-frame').contentWindow.history.back();w.querySelector('#forward').onclick=()=>w.querySelector('#browser-frame').contentWindow.history.forward();}
  if(id==='store')wireStore(w);
  if(id==='settings'){w.querySelectorAll('[data-settings]').forEach(b=>b.onclick=()=>{w.querySelectorAll('[data-settings]').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderSettings(w,b.dataset.settings)});renderSettings(w);}
  if(id==='calculator')wireCalculator(w);
  if(id==='notes'){const area=w.querySelector('#notes-area');area.value=localStorage.getItem('w13-notes')||'';w.querySelector('#save-note').onclick=()=>{localStorage.setItem('w13-notes',area.value);w.querySelector('#note-status').textContent='Guardado localmente';setTimeout(()=>w.querySelector('#note-status').textContent='',1500)}}
  if(id==='terminal')wireTerminal(w);
}
function addVirtualFile(name,type){const files=JSON.parse(localStorage.getItem('w13-files')||'[]');files.push({name,type});localStorage.setItem('w13-files',JSON.stringify(files));renderVirtualFiles()}
function wireCalculator(w){let d=w.querySelector('#calc-display');let expr='';w.querySelectorAll('[data-calc]').forEach(b=>b.onclick=()=>{const v=b.dataset.calc;if(v==='C'){expr='';d.value='0';return}if(v==='⌫'){expr=expr.slice(0,-1);d.value=expr||'0';return}if(v==='='){try{if(!/^[0-9+\-*/().% ]+$/.test(expr))throw 0;expr=String(Function('return '+expr)());d.value=expr}catch{d.value='Error';expr=''}return}expr+=v;d.value=expr});}
function wireTerminal(w){const input=w.querySelector('#terminal-input'),out=w.querySelector('#terminal-output');input.focus();input.onkeydown=e=>{if(e.key!=='Enter')return;const cmd=input.value.trim();input.value='';let r='';if(cmd==='help')r='help, clear, date, apps, open <app>';else if(cmd==='clear')out.innerHTML='';else if(cmd==='date')r=new Date().toString();else if(cmd==='apps')r=state.installed.map(x=>apps[x]?.name).join(', ');else if(cmd.startsWith('open ')){const id=cmd.slice(5).trim();if(apps[id]){openApp(id);r='Abriendo '+apps[id].name}else r='Aplicación no encontrada'}else if(cmd)r='Comando no reconocido';if(r)out.innerHTML+=`<div>W13&gt; ${esc(cmd)}</div><div>${esc(r)}</div>`;}}

function makeDraggable(w){const bar=w.querySelector('.titlebar-title');let dragging=false,dx=0,dy=0;bar.addEventListener('mousedown',e=>{if(w.classList.contains('maximized'))return;dragging=true;dx=e.clientX-w.offsetLeft;dy=e.clientY-w.offsetTop;bar.style.cursor='grabbing';});window.addEventListener('mousemove',e=>{if(!dragging)return;w.style.left=Math.max(0,Math.min(innerWidth-w.offsetWidth,e.clientX-dx))+'px';w.style.top=Math.max(0,Math.min(innerHeight-100,e.clientY-dy))+'px'});window.addEventListener('mouseup',()=>{dragging=false;bar.style.cursor='grab'});}
function focusWindow(w){document.querySelectorAll('.window').forEach(x=>x.classList.remove('focused'));w.classList.add('focused');w.style.zIndex=++state.z;}
function closeWindow(w){state.windows.delete(w.dataset.app);w.remove();updateTaskbar();}
function updateTaskbar(){const bar=document.getElementById('taskbar-apps');bar.innerHTML='';state.windows.forEach((w,id)=>{const b=document.createElement('button');b.className='taskbar-button '+(!w.classList.contains('minimized')?'active':'');b.textContent=apps[id]?.icon||'AP';b.title=apps[id]?.name||id;b.onclick=()=>{w.classList.toggle('minimized');if(!w.classList.contains('minimized'))focusWindow(w);updateTaskbar()};bar.appendChild(b)});}

function updateClock(){const d=new Date();document.getElementById('clock').innerHTML=d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})+'<br>'+d.toLocaleDateString([], {day:'2-digit',month:'2-digit'});}
setInterval(updateClock,1000);updateClock();renderStart();
