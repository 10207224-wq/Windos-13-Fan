# Windows 13 Fan - versión web

Proyecto fan-made independiente creado con HTML, CSS y JavaScript puro.

## Abrir

Abre `index.html` en un navegador moderno.

## Funciones incluidas

- Escritorio y barra de tareas
- Menú Inicio con búsqueda
- Ventanas movibles, minimizables y maximizables
- Explorador virtual con almacenamiento local
- Navegador web basado en iframe
- Store con instalar, abrir y desinstalar apps
- Calculadora funcional
- Notas con guardado local
- Terminal con comandos básicos
- Administrador de tareas básico
- Configuración de tema, acento y wallpaper
- Detección de WebGL/WebGPU cuando el navegador lo expone

## Siguiente etapa

La versión Tauri puede añadir acceso nativo controlado a archivos, procesos, aplicaciones instaladas y métricas del sistema.
